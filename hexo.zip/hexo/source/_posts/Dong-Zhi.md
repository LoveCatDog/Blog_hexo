---
title: '冬至'
date: 2019-12-22 10:44:46
type: tags #（tags,link,categories这三个页面需要配置）
comments: true # (是否需要显示评论，默认true)
description: '冬至大如年，人间小团圆'
top_img: 'http://n.sinaimg.cn/sinacn/w1024h640/20171222/bdd9-fypvuqe9784306.jpg' #设置顶部图
cover: 'http://wx2.sinaimg.cn/orj360/006zeijzgy1ga5d5xwj9uj30gu0b9ajh.jpg'  #缩略图
toc:  #是否显示toc （除非特定文章设置，可以不写）
toc_number: #是否显示toc数字 （除非特定文章设置，可以不写）
copyright: #是否显示版权 （除非特定文章设置，可以不写）
mathjax:
katex:
hide:

---
冬至，数九寒天第一日，美食进补好时节。南有“家家捣米做汤圆”的习俗，北有“冬至不端饺子碗，冻掉耳朵没人管”的说法。
今天，哪个是你的必吃款？

## 冬至大如年，人间小团圆
冬至被视为冬季的大节日

排在二十四节气之首

在民间有“冬至大如年”的讲法

所以古人称冬至为“亚岁”或“小年”


冬至北方吃的是饺子

南方更多吃的是汤圆，寓意团团圆圆。

其他地方还有吃羊肉、吃酿酒等习俗。

岁月匆匆，料峭又一年

祝你

冬至快乐，合家欢乐，健康幸福美满！


