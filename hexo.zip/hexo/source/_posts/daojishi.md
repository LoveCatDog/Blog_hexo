---
layout: _post
title: '19年倒计时'
date: 2019-12-28 18:16:22
type: tags #（tags,link,categories这三个页面需要配置）
comments: true # (是否需要显示评论，默认true)
description: '2019年倒计时的前三天'
top_img: 'https://w.wallhaven.cc/full/0w/wallhaven-0wmg1r.jpg' #设置顶部图
cover: 'https://w.wallhaven.cc/full/4l/wallhaven-4l2x2q.jpg'  #缩略图

---
今天是2019年12月28日 礼拜六 。今天发生一件事：`公司搬家了`
从水湾到后海，这边总体环境还不错，搬家比较累吧，搬一次家，就能重新认识一个地。
其实今天心情不太乐观，或许那玩意来了，还好自己身体没有以前那么疼痛。或许只是工作一方面吧。