## 安装
npm install -g hexo
## 初始化
 hexo init
## 生成
 hexo g 
## 启动服务
 hexo s

 hexo-server : hexo的服务运行环境。
 hexo-browsersync : 页面自动刷新插件。
 hexo-renderer-jade : pug的编译工具，内包括了pug的渲染引擎。
 hexo-renderer-stylus : stylus的渲染引擎。